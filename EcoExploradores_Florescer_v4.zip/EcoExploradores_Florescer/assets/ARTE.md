# Direção de arte — Vale Vivo

Os 100 PNGs de terreno, personagens, objetos e materiais desta revisão foram redesenhados do zero para EcoExploradores. A referência de gênero é o RPG rural acolhedor em pixel art: não foram copiados sprites, personagens, mapas ou texturas de Stardew Valley.

A paleta combina verde musgo, folhagem dourada, pedra acinzentada, madeira castanha, paredes creme, telhados de terracota e máquinas azul-petróleo. As superfícies usam poucos detalhes para manter materiais coletáveis e caminhos legíveis. Os personagens compartilham contornos e luz, com chapéu, mochila e poses próprias nas quatro direções.

Fonte reproduzível da arte: `tools/build-art.cjs`. A ferramenta desenha formas originais diretamente num buffer de pixels; `sharp` apenas codifica os PNGs. Nenhum arquivo de textura antigo é lido ou recolorido. Execute `node tools/build-art.cjs` com Node.js e `sharp` disponíveis para reconstruir os 100 recursos. O jogo distribuído utiliza os PNGs prontos e não precisa de Node.js ou instalações.

A ilustração de capa `ui/vale-title.png` foi criada separadamente com geração de imagem por IA para este projeto. Ela não faz parte do gerador de sprites. Nenhum recurso é baixado durante a partida.

Os nomes e tamanhos dos 100 recursos do pacote original foram mantidos para preservar as âncoras e o carregamento offline. Todas as variantes de terreno correspondentes compartilham o mesmo tom de base; objetos usam fundo transparente.
