#!/usr/bin/env python3
"""Optional local static server. Playing needs no Python when opening index.html."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import argparse

parser = argparse.ArgumentParser(description='Servidor local do EcoExploradores')
parser.add_argument('--port', type=int, default=8000)
parser.add_argument('--bind', default='127.0.0.1')
args = parser.parse_args()
root = Path(__file__).resolve().parent.parent
handler = partial(SimpleHTTPRequestHandler, directory=str(root))
with ThreadingHTTPServer((args.bind, args.port), handler) as server:
    print(f'EcoExploradores: servidor local na porta {args.port}. Ctrl+C para encerrar.', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
