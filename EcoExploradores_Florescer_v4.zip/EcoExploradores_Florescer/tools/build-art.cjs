/* Original EcoExploradores pixel artwork. Generates every runtime PNG from geometry.
   Run: node tools/build-art.cjs (requires sharp only for PNG encoding). */
const sharp=require('sharp');
const fs=require('fs'), path=require('path');
const ROOT=path.resolve(__dirname,'..');
const C={ink:'#35483e',deep:'#315544',green:'#4d7948',leaf:'#6b984e',light:'#94b763',sun:'#bfce80',wood:'#926846',woodD:'#684e3c',woodL:'#bf9160',cream:'#ead6a0',white:'#f7e6b5',roof:'#ab5b48',roofD:'#783f3b',roofL:'#ce7b52',blue:'#497f8c',blueL:'#78b4b3',blueD:'#355c6b',stone:'#9caa91',stoneL:'#c3c5a5',stoneD:'#778775',soil:'#bd9e6e'};
let canvas;
function init(w,h,unit=2){canvas={w,h,unit,buf:Buffer.alloc(w*h*4)};return canvas;}
function color(s){return [parseInt(s.slice(1,3),16),parseInt(s.slice(3,5),16),parseInt(s.slice(5,7),16),255]}
function px(x,y,c){if(x<0||y<0||x>=canvas.w||y>=canvas.h)return;let i=(y*canvas.w+x)*4;for(let k=0;k<4;k++)canvas.buf[i+k]=c[k];}
function r(x,y,w,h,col){const c=color(col),u=canvas.unit;x=Math.round(x*u);y=Math.round(y*u);w=Math.round(w*u);h=Math.round(h*u);for(let j=Math.max(0,y);j<Math.min(canvas.h,y+h);j++)for(let i=Math.max(0,x);i<Math.min(canvas.w,x+w);i++)px(i,j,c);}
function el(x,y,rx,ry,col){const u=canvas.unit;for(let j=Math.floor(y-ry);j<=Math.ceil(y+ry);j++)for(let i=Math.floor(x-rx);i<=Math.ceil(x+rx);i++)if(((i-x)/rx)**2+((j-y)/ry)**2<=1)r(i,j,1,1,col);}
function poly(pts,col){let minX=Math.floor(Math.min(...pts.map(p=>p[0]))), maxX=Math.ceil(Math.max(...pts.map(p=>p[0]))),minY=Math.floor(Math.min(...pts.map(p=>p[1]))),maxY=Math.ceil(Math.max(...pts.map(p=>p[1])));for(let y=minY;y<=maxY;y++)for(let x=minX;x<=maxX;x++){let hit=false;for(let i=0,j=pts.length-1;i<pts.length;j=i++){let a=pts[i],b=pts[j];if((a[1]>y)!=(b[1]>y)&&x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0])hit=!hit;}if(hit)r(x,y,1,1,col);}}
function line(x,y,x2,y2,c,width=1){let n=Math.max(Math.abs(x2-x),Math.abs(y2-y));for(let i=0;i<=n;i++)r(Math.round(x+(x2-x)*i/n),Math.round(y+(y2-y)*i/n),width,width,c);}
function frame(x,y,w,h,c,edge=C.ink){r(x,y,w,h,edge);r(x+1,y+1,w-2,h-2,c);}
function rand(n,seed=1){let v=Math.sin(n*128.21+seed*74.17)*43758.54;return v-Math.floor(v);}
const pending=[];function save(rel){let {w,h,buf}=canvas;pending.push(sharp(buf,{raw:{width:w,height:h,channels:4}}).png().toFile(path.join(ROOT,'assets',rel)));}
function shadow(x,y,rx,ry){el(x,y,rx,ry,C.deep);}
function flower(x,y,col=C.white){r(x,y,1,4,C.green);r(x-2,y-1,5,2,col);r(x-1,y-2,3,4,col);r(x,y-1,1,1,'#d6ae58');}
// Seamless, deliberately quiet terrain; variants preserve their base luminance.
const tiles=['grass','grass2','grass3','grass4','wild','dirt','dirt2','trail','stone','stone2','paver','paver2','road','road2','lab','lab2','water','water2','flowerbed'];
for(let ti=0;ti<tiles.length;ti++){
 const name=tiles[ti];init(48,48);let base=name.startsWith('grass')||name==='wild'?'#7b9e55':name.startsWith('water')?'#5596a2':name.startsWith('road')?'#838b80':name.startsWith('lab')?'#a1b1a0':name.startsWith('stone')?'#acb19a':name.startsWith('paver')?'#c3b691':name==='flowerbed'?'#8e7953':'#c1a16d';r(0,0,24,24,base);
 if(name.startsWith('grass')||name==='wild'){
  for(let n=0;n<26;n++){let x=Math.floor(rand(n,ti+1)*24),y=Math.floor(rand(n,ti+10)*24);r(x,y,2,1,n%3?'#86a85e':'#71944e');if(n%5===0)r(x+1,y-1,1,1,'#95b36b');}
  if(name==='wild')for(let n=0;n<4;n++){let x=Math.floor(rand(n,6)*21),y=Math.floor(rand(n,9)*20)+2;line(x,y,x-1,y-3,C.green);line(x,y,x+2,y-2,C.leaf);}
 }else if(name.startsWith('water')){
  for(let n=0;n<8;n++){let x=Math.floor(rand(n,ti)*24),y=Math.floor(rand(n,ti+11)*24);r(x,y,3+Math.floor(rand(n,2)*4),1,n%2?'#68a8af':'#4a8c99');r(x+1,y+1,2,1,'#5596a2');}
 }else if(name.startsWith('stone')||name.startsWith('paver')){
  for(let y=0;y<24;y+=8)for(let x=-8;x<24;x+=12){let xx=x+(y%16?6:0);r(xx,y,11,7,name.startsWith('paver')?'#cdbf99':'#b8bca4');r(xx,y+6,11,1,name.startsWith('paver')?'#b1a384':'#99a18d');r(xx+1,y+1,9,1,name.startsWith('paver')?'#d8caa5':'#c5c8b1');}
 }else if(name.startsWith('lab')){r(0,0,24,1,'#8c9f92');r(0,0,1,24,'#8c9f92');r(1,1,22,1,'#b7c2ae');r(22,22,1,1,'#758c7c');}
 else {for(let n=0;n<24;n++){let x=Math.floor(rand(n,ti)*24),y=Math.floor(rand(n,ti+3)*24);r(x,y,n%4?1:2,1,name.startsWith('road')?(n%2?'#919788':'#797f75'):(n%2?'#cbae7c':'#b69865'));}if(name==='flowerbed'){for(let i=0;i<5;i++)flower(3+i*4,6+(i%2)*10,i%2?'#e4b877':'#daa090');}}
 save('tiles/'+name+'.png');
}
// Full trees: stepped silhouettes, branch shadows, clusters and sparse highlights.
function tree(name,w=116,h=142,seed=1,pine=false){init(w,h);const W=w/2,H=h/2,x=W/2;shadow(x,H-3,W*.26,2);frame(x-4,H-26,8,22,C.wood);r(x-2,H-25,2,19,C.woodL);r(x+3,H-23,2,19,C.woodD);poly([[x-4,H-8],[x-8,H-3],[x+8,H-3],[x+4,H-8]],C.wood);line(x-3,H-20,x-11,H-28,C.wood,2);line(x+2,H-22,x+10,H-31,C.woodD,2);
 if(pine){for(let i=0;i<5;i++){let y=5+i*9,ww=6+i*3;poly([[x,y],[x-ww,y+20],[x+ww,y+20]],C.deep);poly([[x,y+1],[x-ww+2,y+17],[x+ww-3,y+17]],i%2?C.green:C.leaf);line(x,y+4,x-ww+4,y+14,C.light,1);}}
 else {let clusters=[[x,15,14,12],[x-12,26,13,14],[x+12,25,13,13],[x-16,38,12,12],[x,38,19,16],[x+17,38,11,13],[x,49,13,7]];
 for(let [cx,cy,rx,ry] of clusters)el(cx,cy,rx+1,ry+1,C.deep);
 for(let [cx,cy,rx,ry] of clusters){el(cx-1,cy-2,rx,ry-2,seed===3?'#69884a':C.green);el(cx-3,cy-5,rx-2,ry-4,seed===2?'#80a256':C.leaf);el(cx-5,cy-8,rx-5,ry-7,C.light);}
 for(let i=0;i<45;i++){let xx=8+rand(i,seed)*42,yy=7+rand(i,seed+4)*44;if(((xx-x)/23)**2+((yy-30)/23)**2<.9)r(xx,yy,i%4?2:3,1,i%3?C.light:C.sun);}}
 save('props/'+name+'.png');}
for(let i=1;i<=3;i++)tree(i===1?'tree':'tree'+i,116,142,i);tree('pine',88,138,4,true);
function shrub(name,w,h,flowers=false,planter=false){init(w,h);let W=w/2,H=h/2;shadow(W/2,H-3,W*.42,2);if(planter){poly([[3,H-15],[W-3,H-15],[W-6,H-2],[6,H-2]],C.woodD);r(5,H-13,W-10,9,C.wood);r(5,H-12,W-10,2,C.woodL);for(let x=10;x<W-6;x+=8)r(x,H-11,1,8,C.woodD);}
 for(let i=0;i<6;i++){let x=7+i*(W-14)/5,y=H-10-(i%2)*4;el(x,y,6,6,C.deep);el(x,y-2,6,5,C.green);el(x-2,y-4,3,3,C.leaf);if(flowers)flower(x,y-4,i%3===0?'#db8a81':i%3===1?C.white:'#dcb164');}save('props/'+name+'.png');}
shrub('bush',82,52);shrub('flowers',82,52,true);shrub('planter',102,64,true,true);shrub('flower_island',114,70,true,true);
// Village facades use the same masonry, joinery and roof vocabulary at every size.
function building(name,w,h,type='house',variant=0){init(w,h);const W=w/2,H=h/2,left=5,right=W-5,bottom=H-5,cx=W/2;let top=H*.35;
 shadow(cx,H-3,W*.44,2);frame(left,top,right-left,bottom-top,C.cream,C.woodD);r(left+2,top+2,right-left-4,4,C.white);r(left+1,bottom-6,right-left-2,6,C.stoneD);r(left+3,bottom-5,right-left-6,3,C.stoneL);
 for(let x=left+6;x<right-2;x+=9){r(x,top+9,4,1,'#d8c18e');r(x+3,bottom-11,4,1,'#d8c18e');}
 if(type==='apartments'){frame(left+1,top-11,right-left-2,15,C.cream,C.woodD);top-=8;}
 const roofTop=4,roofBottom=top+3;
 poly([[left-3,roofBottom],[left+7,roofTop],[right-7,roofTop],[right+3,roofBottom]],C.roofD);
 poly([[left,roofBottom-3],[left+8,roofTop+2],[right-8,roofTop+2],[right,roofBottom-3]],variant===2?C.blueD:C.roof);
 for(let yy=roofTop+5;yy<roofBottom-3;yy+=4){let inset=8*(1-(yy-roofTop)/(roofBottom-roofTop));r(left+inset,yy,right-left-inset*2,1,variant===2?C.blue:C.roofL);for(let xx=left+inset+((yy%8)?0:4);xx<right-inset;xx+=8)r(xx,yy-2,1,2,variant===2?C.blue:C.roofD);}
 r(left-2,roofBottom-2,right-left+4,3,C.woodD);r(left,roofBottom-2,right-left,1,C.woodL);
 frame(right-17,2,6,12,C.stone);r(right-18,2,8,2,C.stoneD);
 let doorW=type==='lab'||type==='senai'?12:9,doorH=Math.min(22,H*.3);frame(cx-doorW/2,bottom-doorH,doorW,doorH,C.wood,C.woodD);r(cx-doorW/2+2,bottom-doorH+2,doorW-4,6,C.blueD);r(cx-doorW/2+3,bottom-doorH+2,doorW-6,2,C.blueL);r(cx+doorW/2-3,bottom-6,1,2,C.sun);r(cx-doorW/2-2,bottom,doorW+4,2,C.stoneL);
 function win(x,y,ww=10,hh=12){frame(x,y,ww,hh,C.woodD);r(x+1,y+1,ww-2,hh-2,C.blueD);r(x+2,y+2,ww-4,hh-4,C.blue);r(x+2,y+2,2,hh-5,C.blueL);r(x+ww/2,y+1,1,hh-2,C.cream);r(x+1,y+hh/2,ww-2,1,C.cream);r(x-1,y+hh,ww+2,2,C.wood);}
 const wy=roofBottom+5;win(left+5,wy,Math.min(15,W*.18),13);win(right-Math.min(15,W*.18)-5,wy,Math.min(15,W*.18),13);
 if(type==='apartments'){win(left+5,bottom-21,11,11);win(right-16,bottom-21,11,11);}
 if(type==='shop'){for(let xx=left+2;xx<right-2;xx+=5){r(xx,wy-2,5,5,Math.floor(xx/5)%2?C.white:C.roof);r(xx,wy+3,5,2,Math.floor(xx/5)%2?C.cream:C.roofD);}frame(cx-12,roofBottom-12,24,6,C.cream);r(cx-9,roofBottom-10,18,1,C.green);}
 if(type==='senai'||type==='lab'){frame(cx-13,roofBottom+4,26,7,type==='senai'?C.roofD:C.blueD);r(cx-10,roofBottom+6,20,1,C.white);r(cx-8,roofBottom+8,16,1,C.cream);}
 // Flower boxes frame the entrance, never cover it.
 for(let xx of [left+4,right-13]){frame(xx,bottom-7,9,5,C.wood);for(let j=0;j<3;j++)flower(xx+2+j*2,bottom-9,j%2?C.white:'#d99182');}
 save('props/'+name+'.png');}
for(let [n,w,h,t,v] of [['house',278,206,'house',0],['house2',278,206,'house',2],['shop',278,206,'shop',0],['senai',278,206,'senai',0],['lab',278,206,'lab',2],['senai_atlas',160,133,'senai',0],['lab_atlas',189,120,'lab',2],['house_atlas',172,135,'house',0],['shops_atlas',164,121,'shop',0],['apartments_atlas',155,136,'apartments',0]])building(n,w,h,t,v);
// Furniture and ecology tools.
for(let [name,col] of [['papel','#5a95b2'],['plastico','#c56e58'],['metal','#d3b453'],['vidro','#70915a'],['pilhas','#9780aa']]){init(58,75);shadow(14,35,11,2);frame(5,10,19,24,col);r(6,12,3,19,'#ffffff'); // remove glare via softer palette below
 r(6,12,2,19,col);r(7,12,2,17,name==='metal'?'#e3c66f':'#b8c6a0');r(21,12,2,20,C.ink);frame(3,7,23,5,col);r(7,8,15,2,C.ink);frame(10,17,10,10,C.cream);r(13,19,4,1,C.green);r(12,20,1,4,C.green);r(17,20,1,4,C.green);r(13,24,4,1,C.green);r(6,34,3,2,C.ink);r(20,34,3,2,C.ink);save('props/bin_'+name+'.png');}
for(let name of ['bench','bridge','crate']){let [w,h]=name==='bench'?[94,52]:name==='bridge'?[240,98]:[80,71];init(w,h);let W=w/2,H=h/2;if(name==='bench'){shadow(W/2,H-2,20,2);for(let x of [7,W-9]){r(x,7,3,H-8,C.woodD);r(x-2,H-4,7,2,C.woodD);}for(let y of [3,8])frame(3,y,W-6,4,C.woodL);frame(2,16,W-4,5,C.wood);r(3,16,W-6,1,C.woodL);}else if(name==='bridge'){for(let x=5;x<W-4;x+=7){frame(x,8,7,H-13,C.wood);r(x+1,9,1,H-15,C.woodL);}for(let y of [4,H-7]){frame(2,y,W-4,4,C.woodL);for(let x=2;x<W;x+=28)frame(x,y-3,4,12,C.wood);}}else {frame(4,4,W-8,H-7,C.woodD);frame(5,5,W-10,H-10,C.wood);for(let x=6;x<W-6;x+=7)r(x,6,1,H-12,C.woodD);line(5,6,W-7,H-8,C.woodL,3);line(W-8,6,5,H-8,C.woodL,3);for(let y of [5,H-9])r(4,y,W-8,3,C.woodL);}save('props/'+name+'.png');}
for(let [name,w,h] of [['lamp',46,112],['streetlamp_new',105,139]]){init(w,h);let W=w/2,H=h/2,x=W/2;shadow(x,H-2,6,2);frame(x-2,12,4,H-16,C.wood);r(x-4,H-5,8,3,C.woodD);frame(x-6,4,13,14,C.ink);r(x-4,6,9,10,'#ecd58e');r(x-2,6,1,10,'#fff1ba');r(x-5,2,11,3,C.woodD);r(x-2,0,5,2,C.woodD);r(x,6,1,10,C.wood);save('props/'+name+'.png');}
for(let [name,w,h] of [['sign_schedule',114,124],['sign_map',114,124],['sign_guide',114,124]]){init(w,h);let W=w/2,H=h/2;for(let x of [10,W-12])frame(x,18,4,H-20,C.wood);frame(3,7,W-6,37,C.woodD);frame(5,9,W-10,33,C.woodL);r(8,12,W-16,26,C.cream);r(2,4,W-4,4,C.woodD);r(5,4,W-10,1,C.woodL);if(name==='sign_map'){r(12,16,31,18,'#a3b77b');line(14,29,39,20,C.cream,3);r(29,16,4,18,C.blue);frame(18,17,5,5,C.roof);frame(34,25,5,5,C.roof);}else {for(let y=16;y<34;y+=5){r(13,y,3,2,name==='sign_guide'?C.green:C.roof);r(20,y,22-(y%3)*3,2,C.wood);}}save('props/'+name+'.png');}
init(186,140);shadow(46,65,40,3);el(46,52,42,14,C.stoneD);el(46,49,42,14,C.stoneL);el(46,49,35,10,C.blueD);el(46,48,33,8,C.blueL);el(46,47,25,5,C.blue);frame(42,24,9,29,C.stoneD);r(43,25,4,25,C.stoneL);el(46,25,20,7,C.stoneD);el(46,23,20,7,C.stoneL);el(46,22,16,4,C.blueL);frame(44,7,5,17,C.stone);el(46,7,6,4,C.stoneL);for(let x of [32,60]){r(x,26,2,19,C.blueL);r(x+2,28,1,17,'#a4d0c8');}save('props/fountain.png');
for(let [name,w,h] of [['rock',69,57],['stepstone',70,44]]){init(w,h);let W=w/2,H=h/2;poly([[3,H-6],[5,10],[W*.4,3],[W-8,6],[W-3,H-7],[W-8,H-3],[8,H-3]],C.stoneD);poly([[5,H-10],[7,10],[W*.4,5],[W-9,8],[W-7,H-10]],C.stone);poly([[7,10],[W*.4,5],[W-10,8],[W-14,12],[9,14]],C.stoneL);r(10,H-8,6,1,C.green);save('props/'+name+'.png');}
init(140,166);frame(12,71,46,9,C.stoneD);frame(16,65,38,8,C.stoneL);frame(22,42,26,25,C.stone);frame(26,48,18,10,C.woodD);r(29,51,12,1,C.cream);r(31,54,8,1,C.cream);r(33,19,4,25,C.wood);poly([[35,26],[20,21],[17,11],[29,13],[36,21]],C.green);poly([[36,23],[39,9],[50,5],[49,17],[38,28]],C.leaf);line(35,25,47,10,C.light);save('props/monument.png');
function industrial(name,w,h){init(w,h);let W=w/2,H=h/2;shadow(W/2,H-3,W*.43,2);
 if(name==='conveyor'){frame(3,11,W-6,H-19,C.woodD);frame(6,13,W-12,H-24,C.blueD);for(let x=9;x<W-9;x+=6){r(x,15,3,H-28,C.stoneD);r(x,15,1,H-28,C.stoneL);}for(let x of [9,W-13])frame(x,H-10,4,8,C.wood);r(5,10,W-10,2,C.woodL);}
 else if(name==='pipebank'){for(let y of [11,25,39]){frame(7,y,W-14,6,C.blueD);r(8,y+1,W-16,2,C.blueL);for(let x of [12,W/2,W-17])frame(x,y-1,5,8,C.stone);}for(let x of [9,W-15]){frame(x,8,6,H-14,C.blueD);r(x+1,9,2,H-16,C.blueL);}frame(W*.4,25,13,13,C.woodD);el(W*.4+6,31,6,6,C.roof);el(W*.4+6,31,3,3,C.woodD);}
 else if(name==='workbench'){frame(5,15,W-10,8,C.woodL);r(6,21,W-12,3,C.woodD);for(let x of [8,W-13])frame(x,23,5,H-25,C.wood);r(12,H-12,W-24,3,C.woodD);frame(13,7,20,9,C.blueD);r(15,8,16,2,C.blueL);frame(W-30,9,18,6,C.woodD);r(W-27,7,4,2,C.stoneL);r(W-18,5,3,10,C.stoneD);r(40,12,10,2,C.stoneL);}
 else if(name==='supply_rack'){frame(5,4,W-10,H-9,C.woodD);r(7,6,3,H-13,C.woodL);r(W-10,6,3,H-13,C.woodL);for(let y of [19,34,49]){r(8,y,W-16,3,C.woodL);for(let x=12;x<W-17;x+=15){frame(x,y-10,11,10,y%2?C.blue:C.wood);r(x+2,y-9,7,2,C.cream);}}}
 else if(name==='scanner'){frame(5,H-14,W-10,10,C.woodD);frame(9,8,8,H-21,C.blue);frame(W-17,8,8,H-21,C.blue);frame(11,5,W-22,10,C.blue);r(13,7,W-26,2,C.blueL);r(17,19,W-34,1,'#8db38b');r(17,23,W-34,1,'#abd0a3');frame(27,H-24,15,10,C.wood);}
 else if(name==='power_station'){frame(8,5,W-16,H-10,C.blueD);r(10,7,W-20,H-14,C.blue);r(10,7,W-20,3,C.blueL);frame(15,12,W-30,12,C.woodD);r(17,14,W-34,8,C.cream);poly([[W/2,14],[W/2-4,19],[W/2,19],[W/2-2,23],[W/2+4,18],[W/2,18]],C.roof);for(let y=30;y<H-9;y+=4)r(15,y,W-30,1,C.blueD);}
 else if(name==='terminal'){frame(8,4,W-16,26,C.woodD);frame(10,6,W-20,21,C.blueD);r(13,9,W-26,14,'#79a793');for(let y=11;y<21;y+=4)r(15,y,12-y/2,1,C.cream);frame(19,30,9,H-36,C.blue);frame(10,H-10,W-20,6,C.wood);r(11,H-10,W-22,1,C.woodL);}
 else { // station de triagem, with visible intake and drive wheel.
 frame(7,17,W-14,H-22,C.blueD);r(9,19,W-18,H-26,C.blue);r(9,19,W-18,3,C.blueL);frame(15,7,W*.42,17,C.woodD);frame(18,9,W*.42-6,12,C.blueD);r(20,11,W*.42-10,7,name==='machine_on'?'#87b899':'#647b71');frame(W-43,26,30,31,C.woodD);r(W-40,29,24,25,C.ink);for(let y=32;y<53;y+=5)r(W-38,y,20,2,C.stoneD);frame(15,36,37,25,C.woodD);el(33,48,10,10,C.stone);el(33,48,6,6,C.blueD);el(33,48,2,2,C.woodL);r(21,H-15,W-42,4,C.woodL);for(let x=23;x<W-20;x+=8)r(x,H-15,3,4,C.woodD);frame(W-19,7,8,12,C.woodD);r(W-17,9,4,7,name==='machine_on'?C.light:C.roofD);for(let x of [13,W-21])frame(x,H-8,8,6,C.woodD);}
 save('props/'+name+'.png');}
for(let a of [['terminal',94,107],['machine_off',274,177],['machine_on',274,177],['scanner',146,119],['conveyor',244,91],['workbench',178,92],['power_station',120,110],['supply_rack',126,115],['pipebank',195,118]])industrial(...a);
// Readable collectible silhouettes, all with the same two-pixel outline.
function item(name,w=44,h=49,prop=false){init(w,h);let x=w/4,y=h/4;
 if(name==='papel'){poly([[4,4],[16,4],[19,8],[18,20],[4,20]],C.woodD);poly([[5,5],[15,5],[18,8],[17,19],[5,19]],C.white);r(15,5,1,4,C.cream);r(15,8,3,1,C.wood);for(let yy of [10,13,16])r(7,yy,8,1,C.stoneD);}
 else if(name==='plastico'||name==='vidro'){let col=name==='plastico'?C.blueL:'#78a17c',dark=name==='plastico'?C.blueD:C.deep;frame(8,2,6,4,dark);r(9,2,4,2,name==='plastico'?C.roof:C.wood);poly([[8,6],[14,6],[17,10],[17,20],[5,20],[5,10]],dark);poly([[9,6],[13,6],[15,10],[15,19],[7,19],[7,10]],col);r(8,10,2,8,'#b1cfb4');frame(7,12,9,5,C.cream,dark);r(10,13,3,3,C.green);}
 else if(name==='metal'){el(11,19,7,3,C.blueD);frame(4,6,15,13,C.stone);r(5,7,3,11,C.stoneL);el(11,6,7,3,C.blueD);el(11,5,6,2,C.stoneL);r(9,5,4,1,C.blueD);r(5,11,13,4,C.roof);r(8,12,6,1,C.white);}
 else if(name==='pilhas'){for(let xx of [4,12]){frame(xx,5,7,15,C.woodD);r(xx+1,6,5,5,C.woodL);r(xx+1,11,5,8,C.blueD);r(xx+2,3,3,2,C.stoneL);r(xx+2,13,3,1,C.cream);r(xx+3,12,1,3,C.cream);}}
 else if(name==='eletronico'){frame(3,5,17,13,C.woodD);frame(5,7,13,9,C.blueD);r(7,9,8,4,C.blueL);r(10,18,4,3,C.wood);r(7,21,10,1,C.woodD);}
 else {el(x,y,10,10,C.woodD);el(x,y,8,8,C.stone);for(let i=0;i<8;i++){let a=i*Math.PI/4;r(x+Math.cos(a)*9-2,y+Math.sin(a)*9-2,4,4,C.stone);}el(x,y,4,4,C.blueD);el(x,y,2,2,C.cream);}
 save((prop?'props/':'items/')+name+'.png');}
for(let n of ['papel','plastico','metal','vidro','pilhas','eletronico'])item(n);item('piece',49,50,true);
// A new eco ranger, with distinct front/back/profile poses and alternating stride.
function character(file,w,h,dir='down',stride=0,npc=false){init(w,h);let W=w/2,H=h/2,cx=W/2,foot=H-2;
 // Draw at a fixed 29px logical height within each existing asset footprint.
 let headY=foot-35,bodyY=headY+15,boots=foot-4;
 const shirt=npc==='tech'?'#d9c79c':npc?'#b78362':'#5b9c88',shirtD=npc==='tech'?C.wood:npc?C.roofD:'#3f7468',skin='#ddb18a',skinL='#f0c79c',hair='#76533c';
 if(dir==='left'||dir==='right'){
 let side=dir==='right'?1:-1;
 // Backpack is behind the torso.
 frame(cx-side*6-3,bodyY+1,7,10,C.woodL,C.woodD);r(cx-side*6-2,bodyY+2,4,2,C.cream);
 frame(cx-4,bodyY+11,8,7,C.blueD);r(cx-4+(stride?2:0),boots,6,3,C.woodD);r(cx-3-(stride?3:0),boots-2,5,3,C.wood);
 frame(cx-4,bodyY-1,9,14,shirt,shirtD);r(cx+side*2,bodyY+2,3,7,skin);r(cx+side*2,bodyY+1,3,5,shirt);
 frame(cx-6,headY+4,13,12,hair);r(cx-4,headY+6,10,8,skin);r(cx+(side===1?5:-7),headY+9,2,3,skinL);r(cx+(side===1?3:-4),headY+8,1,2,C.ink);r(cx-4,headY+5,9,2,skinL);
 frame(cx-7,headY,14,6,C.woodL,C.woodD);r(cx-5,headY+1,10,2,C.cream);r(cx+(side===1?3:-10),headY+5,8,2,C.woodD);r(cx+(side===1?3:-10),headY+5,7,1,C.woodL);
 }else {
 frame(cx-7,bodyY+11,14,6,C.blueD);r(cx-6,boots-(stride>0?2:0),5,4,C.woodD);r(cx+2,boots-(stride<0?2:0),5,4,C.woodD);
 frame(cx-7,bodyY,15,14,shirt,shirtD);r(cx-5,bodyY+1,10,2,shirt);r(cx-9,bodyY+3+(stride<0?1:0),3,8,shirtD);r(cx+8,bodyY+3+(stride>0?1:0),3,8,shirtD);r(cx-9,bodyY+9+(stride<0?1:0),3,3,skin);r(cx+8,bodyY+9+(stride>0?1:0),3,3,skin);
 frame(cx-7,headY+4,15,13,hair);r(cx-5,headY+6,11,9,dir==='up'?hair:skin);if(dir!=='up'){r(cx-4,headY+6,9,2,skinL);r(cx-3,headY+9,1,2,C.ink);r(cx+4,headY+9,1,2,C.ink);r(cx,headY+13,2,1,'#b97d67');r(cx-7,headY+10,2,3,skin);r(cx+7,headY+10,2,3,skin);r(cx-4,bodyY+2,2,10,C.woodL);r(cx+4,bodyY+2,2,10,C.woodL);r(cx,bodyY+5,2,2,C.cream);}else{frame(cx-5,bodyY+2,11,11,C.woodL,C.woodD);r(cx-4,bodyY+3,9,3,C.cream);r(cx-2,bodyY+9,5,2,C.wood);}
 frame(cx-8,headY,17,6,C.woodL,C.woodD);r(cx-6,headY+1,13,2,C.cream);r(cx-10,headY+5,21,2,C.woodD);r(cx-9,headY+5,19,1,C.woodL);r(cx+5,headY+1,2,4,C.green);
 }
 save(file);
}
for(let dir of ['down','up','left','right']){character(`player/idle_${dir}.png`,84,104,dir);for(let f=0;f<2;f++)character(`player/walk_${dir}_${f}.png`,84,104,dir,f?1:-1);}
for(let row=0;row<4;row++)for(let f=0;f<4;f++)character(`player/f${row}${f}.png`,64,80,['down','left','right','up'][row],f%2?1:-1);
character('props/guide.png',64,80,'down',0,true);character('props/technician.png',64,80,'down',0,'tech');
Promise.all(pending).then(()=>console.log(`Created ${pending.length} original PNG assets.`)).catch(e=>{console.error(e);process.exitCode=1});
