/* Run: node tests/browser-smoke.cjs
 * Requires Playwright and Chromium; no packages are required to play the game.
 * CHROMIUM_PATH can select another installed Chromium executable.
 */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const { chromium } = require('playwright');
const root = path.resolve(__dirname, '..');
const out = process.env.ECO_TEST_OUTPUT || '/tmp/eco-qa';
fs.mkdirSync(out, { recursive: true });
const checks = [], errors = [], externalRequests = [];
const server = http.createServer((req, res) => {
  const pathname = decodeURIComponent(new URL(req.url, 'http://local').pathname);
  const file = path.resolve(root, '.' + (pathname === '/' ? '/index.html' : pathname));
  if (!file.startsWith(root + path.sep)) { res.writeHead(403).end(); return; }
  fs.readFile(file, (error, content) => {
    if (error) { res.writeHead(404).end(); return; }
    const type = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml' }[path.extname(file)];
    res.setHeader('Content-Type', type || 'application/octet-stream');
    res.end(content);
  });
});
async function check(name, body) { await body(); checks.push(name); console.log('PASS', name); }
async function closeModal(page) {
  if (await page.evaluate(() => !!window.__ecoDebug.modal)) {
    const close = page.locator('[data-action="close"]');
    if (await close.count()) await close.first().click();
    else await page.keyboard.press('Escape');
  }
}
async function atInteraction(page, zone, kind, arg) {
  return page.evaluate(({ zone, kind, arg }) => {
    const d = window.__ecoDebug;
    if (d.state.zone !== zone) d.transfer(zone);
    const object = d.world[zone].interact.find(o => o.kind === kind && (arg === undefined || o.arg === arg));
    if (!object) throw new Error('Missing interaction ' + zone + '/' + kind + '/' + arg);
    // Move test player to a legal interaction position; objective changes use real interaction code.
    for (let radius = 0; radius <= 80; radius += 8) for (let a = 0; a < 32; a++) {
      const x = object.x + Math.cos(a * Math.PI / 16) * radius, y = object.y + Math.sin(a * Math.PI / 16) * radius;
      if (!d.collide(x, y)) { d.state.player.x = x; d.state.player.y = y; return { x, y }; }
    }
    throw new Error('No legal interaction position for ' + kind);
  }, { zone, kind, arg });
}
async function collectOne(page, zone, type) {
  return page.evaluate(({ zone, type }) => {
    const d = window.__ecoDebug;
    if (d.state.zone !== zone) d.transfer(zone);
    const item = d.world[zone].items.find(i => !i.taken && (!type || i.type === type));
    if (!item) throw new Error('Missing untaken item: ' + zone + '/' + type);
    d.state.player.x = item.x; d.state.player.y = item.y;
    const before = d.state.collected;
    d.interact();
    if (d.state.collected !== before + 1) throw new Error('Collect did not change collected counter');
    return item.type;
  }, { zone, type });
}
async function sortSelected(page) {
  const { zone, type, before } = await page.evaluate(() => ({zone:__ecoDebug.state.zone,type:__ecoDebug.state.inventory[__ecoDebug.state.selected],before:__ecoDebug.state.sorted}));
  await atInteraction(page, zone, 'bin', type);
  await page.keyboard.press('e');
  assert.equal(await page.evaluate(() => __ecoDebug.state.sorted), before + 1);
}
async function auditReachability(page) {
  return page.evaluate(() => {
    const d = window.__ecoDebug, originalZone = d.state.zone, originalSorted = d.state.sorted;
    const reports = [];
    d.state.sorted = 99;
    for (const zone of Object.keys(d.world)) {
      d.transfer(zone);
      const width = d.world[zone].background.width, height = d.world[zone].background.height, step = 12;
      const cols = Math.floor(width / step) + 1, rows = Math.floor(height / step) + 1;
      const walkable = new Uint8Array(cols * rows), seen = new Uint8Array(cols * rows);
      for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) walkable[y * cols + x] = !d.collide(x * step, y * step);
      const spawn = { ...d.state.player };
      let start = -1, distance = Infinity;
      for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) if (walkable[y * cols + x]) {
        const dist = Math.hypot(x * step - spawn.x, y * step - spawn.y);
        if (dist < distance) { distance = dist; start = y * cols + x; }
      }
      const queue = [start]; seen[start] = 1;
      for (let q = 0; q < queue.length; q++) {
        const i = queue[q], x = i % cols, y = Math.floor(i / cols);
        for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
          const nx = x + dx, ny = y + dy, ni = ny * cols + nx;
          if(nx < 0 || nx >= cols || ny < 0 || ny >= rows || seen[ni] || !walkable[ni]) continue;
          if(d.collide((x+nx)*step/2,(y+ny)*step/2)) continue;
          seen[ni]=1;queue.push(ni);
        }
      }
      const objectives = [...d.world[zone].interact.map(o=>({...o,label:o.kind+'/'+o.arg})),...d.world[zone].items.map(o=>({...o,label:'item/'+o.type}))];
      const unreachable = objectives.filter(o=>{
        for(let y=Math.max(0,Math.floor((o.y-80)/step));y<=Math.min(rows-1,Math.ceil((o.y+80)/step));y++)
          for(let x=Math.max(0,Math.floor((o.x-80)/step));x<=Math.min(cols-1,Math.ceil((o.x+80)/step));x++)
            if(seen[y*cols+x]&&Math.hypot(x*step-o.x,y*step-o.y)<80)return false;
        return true;
      }).map(o=>({label:o.label,x:o.x,y:o.y}));
      reports.push({zone,width,height,reachableCells:queue.length,objectives:objectives.length,spawnCollision:d.collide(spawn.x,spawn.y),unreachable});
    }
    d.state.sorted = originalSorted; d.transfer(originalZone);
    return reports;
  });
}
(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const url = `http://127.0.0.1:${server.address().port}/?debug=1`;
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', args: ['--no-sandbox'] });
  try {
    const context = await browser.newContext({ viewport: { width: 1440, height: 960 } });
    const page = await context.newPage();
    page.on('pageerror', error => errors.push(error.message));
    page.on('request', request => { if (!request.url().startsWith('http://127.0.0.1:') && !request.url().startsWith('data:')) externalRequests.push(request.url()); });
    await page.goto(url);
    await page.waitForFunction(() => window.__ecoDebug?.state && Object.values(__ecoDebug.assets).every(a=>a.complete));
    await check('All image assets load', async () => assert.deepEqual(await page.evaluate(() => Object.entries(__ecoDebug.assets).filter(([,a])=>!a.naturalWidth).map(([k])=>k)), []));
    await page.screenshot({ path: path.join(out, 'title.png') });
    await page.locator('[data-action="start"]').click();
    await check('Keyboard movement and sprint', async () => {
      await page.evaluate(()=>{__ecoDebug.state.player.x=600;__ecoDebug.state.player.y=640});
      const before=await page.evaluate(()=>__ecoDebug.state.player.x);
      await page.keyboard.down('d'); await page.waitForTimeout(300); await page.keyboard.up('d');
      const walked=await page.evaluate(()=>__ecoDebug.state.player.x);
      assert.ok(walked>before+20,'Player should move to the right');
      await page.evaluate(()=>{__ecoDebug.state.player.x=600;__ecoDebug.state.player.y=640});
      await page.keyboard.down('Shift');await page.keyboard.down('d');await page.waitForTimeout(300);await page.keyboard.up('d');await page.keyboard.up('Shift');
      const ran=await page.evaluate(()=>__ecoDebug.state.player.x);
      assert.ok(ran-before>(walked-before)*1.15,'Sprint should exceed walking speed');
    });
    await check('World bounds block movement', async()=>{
      await page.evaluate(()=>{__ecoDebug.state.player.x=50;__ecoDebug.state.player.y=550});
      await page.keyboard.down('a');await page.waitForTimeout(250);await page.keyboard.up('a');
      assert.ok(await page.evaluate(()=>__ecoDebug.state.player.x>=45));
    });
    await check('Collect, incorrect sorting, and correct sorting', async()=>{
      const type=await collectOne(page,'lobby');
      const before=await page.evaluate(()=>({sorted:__ecoDebug.state.sorted,score:__ecoDebug.state.score,inventory:[...__ecoDebug.state.inventory]}));
      await atInteraction(page,'lobby','bin',type==='papel'?'metal':'papel');await page.keyboard.press('e');
      assert.deepEqual(await page.evaluate(()=>({sorted:__ecoDebug.state.sorted,score:__ecoDebug.state.score,inventory:[...__ecoDebug.state.inventory]})),before);
      await sortSelected(page);
      assert.equal(await page.evaluate(()=>__ecoDebug.state.inventory.length),0);
    });
    await check('Locked laboratory rejects early entry',async()=>{
      await page.evaluate(()=>__ecoDebug.transfer('lab'));
      assert.notEqual(await page.evaluate(()=>__ecoDebug.state.zone),'lab');
    });
    await check('Pause freezes movement; help and schedule work',async()=>{
      await page.keyboard.press('Escape');
      const before=await page.evaluate(()=>({...__ecoDebug.state.player}));
      await page.keyboard.down('d');await page.waitForTimeout(150);await page.keyboard.up('d');
      assert.equal(await page.evaluate(()=>__ecoDebug.state.player.x),before.x);
      await page.locator('[data-action="help"]').click();await closeModal(page);
      await atInteraction(page,'lobby','schedule');await page.keyboard.press('e');
      await page.locator('#scheduleSearch').fill('Tropical');assert.ok((await page.locator('#scheduleResults').innerText()).includes('Tropical'));
      await page.locator('#scheduleSearch').fill('zzznobairro');assert.ok((await page.locator('#scheduleResults').innerText()).includes('Nenhum'));
      await closeModal(page);
    });
    const reachability=await auditReachability(page);
    fs.writeFileSync(path.join(out,'reachability.json'),JSON.stringify(reachability,null,2));
    await check('All region objectives reachable from spawn',async()=>{
      for(const report of reachability){assert.equal(report.spawnCollision,false,report.zone+' spawn collision');assert.deepEqual(report.unreachable,[],report.zone+' inaccessible objectives');}
    });
    // Fill the recycling goal through actual pickup and bin interactions.
    await check('Garden restoration locked until prerequisites',async()=>{
      await atInteraction(page,'garden','plant','ervas');await page.keyboard.press('e');
      assert.deepEqual(await page.evaluate(()=>__ecoDebug.state.planted),[]);await closeModal(page);
    });
    await check('Recycling objective and machine prerequisite',async()=>{
      for(const zone of ['lobby','park','city','garden']){
        if(!(await page.evaluate(z=>!!__ecoDebug.world[z],zone)))continue;
        while(await page.evaluate(()=>__ecoDebug.state.sorted<12)){
          if(!(await page.evaluate(z=>__ecoDebug.world[z].items.some(i=>!i.taken),zone)))break;
          await collectOne(page,zone);await sortSelected(page);
        }
      }
      assert.ok(await page.evaluate(()=>__ecoDebug.state.sorted>=12));
      await atInteraction(page,'lab','machine');await page.keyboard.press('e');
      assert.equal(await page.evaluate(()=>__ecoDebug.state.machine),false,'Missing piece must block machine');
      await atInteraction(page,'city','piece');await page.keyboard.press('e');
      assert.equal(await page.evaluate(()=>__ecoDebug.state.piece),true);
      await atInteraction(page,'lab','machine');await page.keyboard.press('e');
      assert.equal(await page.evaluate(()=>__ecoDebug.state.machine),true);
    });
    await check('Restoration completes mission exactly once',async()=>{
      assert.equal(await page.evaluate(()=>__ecoDebug.state.finished),false);
      for(const id of ['ervas','flores','arvores']){await atInteraction(page,'garden','plant',id);await page.keyboard.press('e');}
      assert.equal(await page.evaluate(()=>__ecoDebug.state.finished),true);
      assert.equal(await page.evaluate(()=>__ecoDebug.state.planted.length),3);
      await closeModal(page);
      const score=await page.evaluate(()=>__ecoDebug.state.score);
      await atInteraction(page,'garden','plant','arvores');await page.keyboard.press('e');
      assert.equal(await page.evaluate(()=>__ecoDebug.state.score),score,'No duplicate planting reward');
    });
    await check('Save and resume restore progress and collected items',async()=>{
      await page.evaluate(()=>__ecoDebug.saveGame());
      const before=await page.evaluate(()=>({zone:__ecoDebug.state.zone,sorted:__ecoDebug.state.sorted,score:__ecoDebug.state.score,planted:__ecoDebug.state.planted,finished:__ecoDebug.state.finished,taken:Object.values(__ecoDebug.world).flatMap(w=>w.items.filter(i=>i.taken).map(i=>i.id))}));
      await page.reload();await page.waitForSelector('[data-action="continue"]');await page.locator('[data-action="continue"]').click();
      const after=await page.evaluate(()=>({zone:__ecoDebug.state.zone,sorted:__ecoDebug.state.sorted,score:__ecoDebug.state.score,planted:__ecoDebug.state.planted,finished:__ecoDebug.state.finished,taken:Object.values(__ecoDebug.world).flatMap(w=>w.items.filter(i=>i.taken).map(i=>i.id))}));
      assert.deepEqual(after,before);
    });
    for(const zone of await page.evaluate(()=>Object.keys(__ecoDebug.world))){
      await closeModal(page);await page.evaluate(z=>__ecoDebug.transfer(z),zone);await page.waitForTimeout(1700);
      await page.screenshot({path:path.join(out,zone+'.png')});
      if(zone==='garden'){
        await page.evaluate(()=>{__ecoDebug.state.player.x=950;__ecoDebug.state.player.y=850;document.getElementById('toast').classList.add('hidden');});
        await page.waitForTimeout(1100);await page.screenshot({path:path.join(out,'garden-restored.png')});
      }
    }
    await check('Corrupted save recovers to a fresh adventure',async()=>{
      await page.evaluate(()=>{__ecoDebug.state.started=false;localStorage.setItem(__ecoDebug.SAVE_KEY,'{broken')});
      await page.reload();await page.waitForSelector('[data-action="start"]');
      assert.equal(await page.locator('[data-action="continue"]').count(),0);
      await page.locator('[data-action="start"]').click();assert.equal(await page.evaluate(()=>__ecoDebug.state.sorted),0);
    });
    await check('Eight-slot capacity and keyboard/click selection',async()=>{
      for(let i=0;i<8;i++)await collectOne(page,'lobby');
      assert.equal(await page.evaluate(()=>__ecoDebug.state.inventory.length),8);
      const ninth=await page.evaluate(()=>{const d=__ecoDebug,it=d.world.lobby.items.find(i=>!i.taken);d.state.player.x=it.x;d.state.player.y=it.y;const count=d.state.collected;d.interact();return {count,after:d.state.collected,taken:it.taken}});
      assert.equal(ninth.after,ninth.count);assert.equal(ninth.taken,false);
      await page.keyboard.press('8');assert.equal(await page.evaluate(()=>__ecoDebug.state.selected),7);
      await page.keyboard.press('q');assert.equal(await page.evaluate(()=>__ecoDebug.state.selected),0);
      await page.locator('#inventory .slot').nth(1).click();assert.equal(await page.evaluate(()=>__ecoDebug.state.selected),1);
    });
    await check('Repeated pause and resume retain play state',async()=>{
      for(let i=0;i<3;i++){
        await page.keyboard.press('Escape');assert.equal(await page.evaluate(()=>__ecoDebug.modal),'pause');
        await page.keyboard.press('Escape');assert.equal(await page.evaluate(()=>__ecoDebug.modal),'');
      }
      assert.equal(await page.evaluate(()=>__ecoDebug.state.inventory.length),8);
    });
    await check('No external requests or JavaScript exceptions',async()=>{assert.deepEqual(errors,[]);assert.deepEqual(externalRequests,[]);});
    const normal = await context.newPage();
    await normal.goto(url.replace('?debug=1',''));
    await normal.waitForSelector('[data-action="start"], [data-action="continue"]');
    await check('Debug hooks disabled in normal play',async()=>assert.equal(await normal.evaluate(()=>typeof window.__ecoDebug),'undefined'));
    await normal.close();
    const mobileContext=await browser.newContext({viewport:{width:844,height:390},isMobile:true,hasTouch:true,deviceScaleFactor:1});
    const mobile=await mobileContext.newPage();mobile.on('pageerror',error=>errors.push(error.message));
    await mobile.goto(url);await mobile.waitForSelector('[data-action="start"]');await mobile.locator('[data-action="start"]').click();
    await check('Touch movement and responsive layout',async()=>{
      await mobile.evaluate(()=>{__ecoDebug.state.player.x=600;__ecoDebug.state.player.y=640});
      const control=mobile.locator('[data-dir="right"]');await control.waitFor({state:'visible'});const box=await control.boundingBox();
      await mobile.mouse.move(box.x+box.width/2,box.y+box.height/2);await mobile.mouse.down();await mobile.waitForTimeout(300);await mobile.mouse.up();
      assert.ok(await mobile.evaluate(()=>__ecoDebug.state.player.x>620));
      assert.ok(await mobile.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),'No horizontal page overflow');
    });
    await check('Touch pause and map are usable in landscape',async()=>{
      await mobile.locator('#touchMenu').click();
      assert.equal(await mobile.evaluate(()=>__ecoDebug.modal),'pause');
      await mobile.locator('[data-action="close"]').click();
      await mobile.locator('#touchMap').click();
      assert.equal(await mobile.evaluate(()=>__ecoDebug.modal),'map');
      await mobile.locator('[data-action="close"]').click();
    });
    await mobile.screenshot({path:path.join(out,'mobile-landscape.png')});
    await mobile.setViewportSize({width:390,height:844});await mobile.screenshot({path:path.join(out,'mobile-portrait.png')});
    await mobileContext.close();
    await context.close();
    const fileContext=await browser.newContext();const filePage=await fileContext.newPage();
    let fileResult='passed';
    try{await filePage.goto('file://'+path.join(root,'index.html'));await filePage.waitForSelector('[data-action="start"]');}catch(e){fileResult=e.message.includes('ERR_BLOCKED_BY_ADMINISTRATOR')?'blocked by Chromium administrator policy':e.message;}
    await fileContext.close();
    fs.writeFileSync(path.join(out,'results.json'),JSON.stringify({checks,errors,reachability,fileResult},null,2));
    console.log(JSON.stringify({passed:checks.length,fileResult,screenshots:out}));
  } finally { await browser.close(); server.close(); }
})().catch(error=>{console.error(error);fs.writeFileSync(path.join(out,'failure.json'),JSON.stringify({checks,errors,error:error.stack},null,2));server.close();process.exitCode=1});
