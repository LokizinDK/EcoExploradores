// Dados locais e editáveis; nenhum acesso à rede é necessário.
window.CRONOGRAMA = [
 {dias:['Segunda-feira','Sexta-feira'],rotas:[['17h30','Tropical I e II'],['18h30','América'],['19h00','Avelino Piacentini'],['19h30','Silvana'],['20h00','Batel I e II, Mário Figueiredo, Santa Cruz, Modelo, Esperança e José Richa'],['21h00','Milton de Paula Walter'],[null,'Jardins Conrado, Isabel, Três Marias, Maria Clara, Ilha Bela, Brasília, Albuquerque, San Marino, Kimberlim, Paulista e Aeroporto; Vila Corinthians, Vila Nossa Senhora Aparecida, Village das Hortênsias e Conjunto Parigot de Souza']]},
 {dias:['Terça-feira','Quinta-feira'],rotas:[['17h30','Copacabana I e II'],['18h30','Vila Rio Grande e Voidelo'],['19h00','Ipanema I e II'],['20h30','Vila Cândida, Indianópolis e Lar Paraná']]},
 {dias:['Quarta-feira','Sábado'],rotas:[['17h30','Novo Centro'],['18h30','Panambi, Vitória, Santa Casa, Bela Vista e Ecoville'],[null,"Centro e áreas comerciais; Jardins São Pedro, Curitiba, São Sebastião, Santa Nilce I, Zoraide, São João, Paraíso do Campo, Joana D'Arc, Aurora, Ana Elisa, Constantino e Antonio Toledo Silveira; Vila Urupês, Vila Guarujá, Villaggio Trombini e Distrito de Piquirivaí"]]}
];
